<!-- Page: 1 -->

## FEATURES

Graded Quality Books.
Graded Quality Books.
Graded Quality Books.

Covering cumulative syllabus. Textbook cum workbook style for Primary.

In-depth coverage of any one application or language in each book.

Activity corner.

Moderate price.

## SUPPORTIVE SERVICES

Monthly Tentative Schedule or syllabus
each standard in order to effectively
conduct the curriculum

Required software for the Curriculum

Terminal Question Papers

Teachers Key book

Scan to view Value Added Services Demo

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_12_1767678514329564633.jpg)

## VALUE ADDED SERVICES

Work Sheets

Interactive book back

exercises for primary.

Online Exam Software

e-Book Software Voice Enabled

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_19_1767678514334209419.jpg)

## ABOUT US

SAMSEL Publications is a unit of U.S. UNIQUE SOFTWARE SOLUTIONS, a leading company in Chennai providing Total IT Solutions for schools. We are the pioneers in implementing Computer Literacy Programme at schools for 2 decades.

Emerging Technologies, Wireless networks and IoT are the other major concepts covered in higher classes. Algorithms, Flowcharts and Coding techniques using Scratch Jr and Scratch 3.0 are dealt in depth for primary level. This series provides a structured approach to learning AI, robotics, and programming concepts.

Word, Excel and PowerPoint 2016 are dealt separately with ample illustrations and Try in your lab exercises. MS Office, Word, Excel, PowerPoint and Access 2007 books are also available.

Windows 10 platform, Paint, Logo Programming, MS Word, PowerPoint & Excel 2010 at primary level, HTML, C++ Prog., JavaScript, MySQL & Python for higher classes. Hint, Do you know and Do it yourself are the added features of this series.

Windows 7 operating system, Office 2007 suite at various levels, designing tool - Photoshop and also covering programming concepts C & HTML.

Young Wizard Series comprising of 5 different titles at primary level, titled Level 1 to 5, this series is multicolour with colourful presentations and completely activity based, covering Windows 7 & Animation curriculum, comprising of learning to work with Windows OS, MS Word 2007, MS Paint, Internet, Multimedia tools, SwishMax and Macromedia Flash.

C++ Programming.

My Computer Series comprising of 5 different titles at primary level, titled Grade I to V, this series has colourful presentations and workbook activities, covering Windows curriculum only, learning to work with Windows XP OS, MS Paint, WordPad and Web Designing.

Right Click Series Information & Communication Technology covering windows curriculum along with application packages and programming languages such as Basic prog. Visual Basic & IT Applications in titles from ICT - Std III to IX.

Little Wizard Series comprising of 2 titles for kindergarten level, titled Kids Level 1 & 2 is complete with instructions for teachers, parents and students needed for an informative, interesting and entertaining learning experience.

My First Stroke Series Cursive Writing Books - Comprising of 7 different titles graded from LKG to Std V. These books enable children to improve their handwriting skills. This series covers small letters, capital letters, words, short and long sentences.

My First Stroke Series Tamil Writing Books - Comprising of 7 different titles graded from LKG to Std V. These books will enable the children to learn Tamil basics in a very interesting manner. This series covers Tamil letters, words and sentences.

Our success is truly based on the systematic curriculum framed by us, knowing the IQ level of students at different grades purely by the experience we have gained over the years with high expertise, commitment and an innovative team of faculty members and editorial board members.

With the state of the art technology ever changing, we upgrade our titles regularly keeping in pace with the latest trends in IT technology and in accordance to the valuable suggestions and support given by major institutions across the states.

We are accredited by more than 1500 schools prescribing our curriculum, with major group institutions coming under our curriculum across Tamil Nadu and other states. Our books are widely accepted in Andhra Pradesh, Kerala, Karnataka & parts of Northern India for State/ CBSE/ ICSE board Syllabus.

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_36_1767678514859741966.jpg)

# COMPUTER BOOKS
FOR ACADEMIC
EXCELLENCE

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_38_1767678514861106350.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_39_1767678514866466386.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_40_1767678514869294573.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_41_1767678514873973963.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_42_1767678514876289836.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_43_1767678514876731402.jpg)

CATALOGUE
2026-27

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_45_1767678514878639132.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_46_1767678514881635123.jpg)

Computer - its characteristic & parts, Input, Processing & Output Units, Intro. to Win 10, Tax Pintil - Its Tools & Effects.

Computer Fundamentals, Intra. to Win 10, MS Print & MSW Logo, Micro Computer & its types, Memory Unit, Computer in different fields.

Keyboard & its keys, Software & its types, Input, Output & Data Storage Devices, Working with Windows 10, Intro to MS Word 2010, Microsoft MS Paint, Advanced MSW Logo commands

Types of Data, Working with Files & Folders in Windows 10, more on MS Word 2010, Intra. in MS Powerpoint 2010.

5 Evolving of Computers, Windows 10 - Personalizing Desktop, Animations & Transitions in MS PowerPoint 2010, Intro. to MS Excel 2010, Calculations, Formatting worksheets & Insertion of charts.

OS & its type, Number System Conversions, Intro. to HTML, Internet & its uses, Basics of C++ prog.

Microprocessor & its types, Web apps, Number System – Binary addition & subtraction, More on HTML, Intra. to Javascript, Arrays & Functions in C++ prog., OOPS concept

Software & its types, DBMS, MS Access 2010 — Intra, Query, Forms & Reports, JavaScript — Control statements & its types, Basics of Python

Stu9 Communication Protocol — its types, Networking devices, Pugemaker, Mobile Networking, Intro. to MySQL, Python — Control Structure & Functions

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_56_1767678514899596468.jpg)

<!-- A unit of USS UNIQUE SOFTWARE SOLUTIONS -->

<!-- Page: 2 -->

<!-- 1cm of rain -->

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_1_1767678514974002345.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_2_1767678514974143763.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_3_1767678514974392996.jpg)

## i-Whizz Series INFORMATION & COMMUNICATION

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_5_1767678514975059896.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_6_1767678514975262129.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_7_1767678514976078440.jpg)

CPU & its units, Knowing Windows 7, Types of Micro computers, Computers in various fields. Tux Paint Level 2.

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_9_1767678514976874245.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_10_1767678514977078790.jpg)

Computer Fundamentals, Input, Output & Data Storage devices, Windows 7 - Features & Components, Paint - Components

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_12_1767678514977971273.jpg)

Std 4 Type tutor, Working with MS Office Picture Manager PowerPoint 2007, Computer Ethics: Do's & Don't of computer.

Std 5 Generation of Computers, Hardware & Software - its types, Windows 7 Accessories, MS Office Publisher 2007 & its tools, Internet & its use

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_15_1767678514980115885.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_16_1767678514980233126.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_17_1767678514980439781.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_18_1767678514980676431.jpg)

Windows 7 OS - Features, File management, MS Word 2007, Programming fundamentals using QBasic.

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_20_1767678514981556050.jpg)

MS Excel 2007 - Intro-Formatting, Inserting - Shapes, SmartArt & Chart, Calculation using different functions, sorting & filtering data, More about QBasic, Flash, Email - advantages, IT Applications.

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_22_1767678514982697330.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_23_1767678514982904709.jpg)

Virus & Anti-virus, Web designing using HTML, C Prog. intro. and prog. execution. Image editing using Photoshop, IT Applications.

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_25_1767678514983881081.jpg)

HTML - tables, frames and forms, Introduction to XML, C Programming - Control structures, Arrays and Functions, Photoshop - Tools, layer & its effects, IT Applications.

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_27_1767678514984962485.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_28_1767678514985350989.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_29_1767678514985842239.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_30_1767678514987850662.jpg)

## Application Series 2007

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_32_1767678514988560055.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_33_1767678514989350740.jpg)

MS POWERPOINT 2007

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_35_1767678514991239982.jpg)

Advanced study in MS PowerPoint 2007

ACCESS 2007 Advanced study in MS Access 2007

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_38_1767678514993094097.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_39_1767678514993108058.jpg)

## i-Bot Series New

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_41_1767678514995851084.jpg)

Computer, its features, Parts, and uses in different fields, ScratchJr – Intro, its components, blocks and their usage, Do's and Don'ts of computer.

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_43_1767678514997866865.jpg)

Input and Output units, Memory unit – Its types, Peripheral devices, ScratchJr – different code blocks, Paint Editor – Its tools and their uses.

![image](https://static-us-img.skywork.ai/prod/nexus/1767678514/cropped_image_45_1767678514999355165.jpg)

Computer fundamentals, Types of Computer, Hardware & Software – their types, Languages, Intro. to OS, Getting started with Scratch 3, Code blocks, Working with sprites.

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_47_1767678515000013419.jpg)

Desktop Computer – Its types, Robots – Its types, Network devices, Features of MS Word & AI, Scratch 3 – Different code blocks and their usage.

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_49_1767678515002691087.jpg)

Algorithms, Pseudocode and flowcharts, Types of intelligence, Human & Machine intelligence, AI & MS PowerPoint, Scratch 3 – Loops and conditions, Variables, Broadcasting messages.

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_51_1767678515003691880.jpg)

Intro. to AI, AI & Robotics, Networking,
Intro. to Python, Block chain for Beginners,
Visualizations with Plotfy

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_53_1767678515005263498.jpg)

More on AI & Robotics, Intro. & Core Concepts in C & C++, More on Python, Intro. to HTML 5, CSS, ITES, Computer Networking

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_55_1767678515006550749.jpg)

Control Structures in Python and Intro. to Tkinter GUI, Embedded Programming and Simulation in C++, Advanced C++ Techniques, Cyber Security, Emerging Technologies, Exploring Wireless Networking

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_57_1767678515009927422.jpg)

Connectivity of Data for web pages and intro. to DBMS, Data structures, Functions & Modules in Python, AI and Data Science, Algorithms with Data Structure, IOT

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_59_1767678515011555971.jpg)

## Young Wizard Series

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_61_1767678515016068576.jpg)

Computer parts, Storage devices, Introduction to Windows 7 & Paint

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_63_1767678515019073355.jpg)

Computer basics, Data & its types, Memory unit, Multimedia & its tools, More about Windows 7 & Paint

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_65_1767678515024948159.jpg)

Computer Evolution - Its types & applications, Windows 7 desktop, Internet and Multimedia concepts, Working with MS PowerPoint 2007

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_67_1767678515026466002.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_68_1767678515033273961.jpg)

Exploring Windows Operating System, Working with MS Word 2007, Draw & Animate using SwishMax

MS Excel\(^{®}\) 2007, Draw & Animate using Flash,

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_71_1767678515040282079.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_72_1767678515048532664.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_73_1767678515054852499.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_74_1767678515062622782.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_75_1767678515069781741.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_76_1767678515075935829.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_77_1767678515084142817.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_78_1767678515091418149.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_79_1767678515105806029.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_80_1767678515111188840.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_81_1767678515121811240.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_82_1767678515130353917.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_83_1767678515136033769.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_84_1767678515147133981.jpg)

## Application Series 2016
WITH QR CODE ENABLED VIDEOS

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_86_1767678515162094435.jpg)

> nt 2016 Advanced study in MS PowerPoint 2016

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_88_1767678515263148424.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_89_1767678515279046743.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_90_1767678515292291993.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_91_1767678515311820727.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_92_1767678515312903053.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_93_1767678515326630363.jpg)

Computer Fundamentals, Animation, Tamil Computing MS Excel, Basic Prog. & IT Applications.

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_95_1767678515339029975.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_96_1767678515342006546.jpg)

Computer Virus, MS Excel, HTML, Tamil Computing and IT Applications.

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_98_1767678515356225507.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_99_1767678515374087105.jpg)

Computer Concepts, HTML, Visual Basic, Intro. to Linux and IT Applications.

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_101_1767678515557507900.jpg)

## Programming Series

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_103_1767678515572087701.jpg)

HTML (English & Tamil) Internet Concepts, Programming in HyperText Markup Language.

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_105_1767678515584390643.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_106_1767678515586800755.jpg)

## My Computer Series

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_108_1767678515597665376.jpg)

Computer Fundamentals, Input & Output unit, Keyboard and Mouse handling, Intro. to Win XP with Activities. Practical Concept: Paint - Level I

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_110_1767678515601205896.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_111_1767678515603521383.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_112_1767678515611769714.jpg)

Win XP Concepts, Memory Unit, Multimedia & its tools. Practical: More about Paint - Level II

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_114_1767678515619193513.jpg)

Evolution of Computers, Computer Types & its application
More about Win XP, Internet & Multimedia applications.
Practical: Advanced Paint - Level III

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_116_1767678515625202191.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_117_1767678515626590491.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_118_1767678515627741784.jpg)

Working with Win XP OS & PowerPoint, WordPad Practical: WordPad. PowerPoint

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_120_1767678515632428498.jpg)

Exploring the Net, Web Design @ Jr Level & Computer Networking. Practical: Notepad. HTML

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_122_1767678515641233676.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_123_1767678515641342830.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_124_1767678515642920251.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_125_1767678515646283081.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_126_1767678515653170569.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_127_1767678515654076811.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_128_1767678515656228716.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_129_1767678515656623914.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_130_1767678515657612754.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_131_1767678515658950628.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_132_1767678515659789017.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_133_1767678515668220067.jpg)

## Little Wizard Series

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_135_1767678515672690834.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_136_1767678515672649354.jpg)

MY FIRST COMPUTER BOOK

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_138_1767678515675148409.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_139_1767678515675461641.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_140_1767678515676204703.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_141_1767678515677044368.jpg)

## Tamil Writing Books

(உயிர்முத்துகள், மூமியமுத்துகள், ஆயுத
எழுத்து, மழலைப் பாடல்கள் மற்றும் கதைப்பகுதி)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_144_1767678515687417232.jpg)

இனிய தமிழ் பழகுதல் - UKG
(உயிரெழுத்துகள், மெய்யெழுத்துகள்)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_146_1767678515689924162.jpg)

இனிய தமிழ் பழகுதல் - முதல் நிலை
(உயிரிய மற்றும் வடமொழி எழுத்துகள்)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_148_1767678515690636883.jpg)

இனிய தமிழ் எழுத்துப் பயிற்சி - 2.ஆம் நிலை
(உயிர்மேய் எழுத்துகளின் வரிசை மற்றும்
சிறிய வார்த்தைகள்)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_150_1767678515692064065.jpg)

இனிய தமிழ் எழுத்துப் பயிற்சி - 3ஆம் நிலை
(ஒளிகள்/எதிர்சொற்கள்/இரட்டைக்கிளவி/ஒருமை
பன்மை மற்றும் பல)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_152_1767678515694138459.jpg)

இனிய தமிழ் எழுத்துப் பயிற்சி - 4ஆம் நிலை
(பழமொழி/இரட்டைக்கிளவி/அடுக்குத்தொடர்
மற்றும் எதிர்சொல் வாக்கியங்கள்)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_154_1767678515697329201.jpg)

இனிய தமிழ் எழுத்துப் பயிற்சி - 5ஆம் நிலை
(தினை, பால், என), இடம், காலம், பொது அழிவு.
தகவல்கள், திருக்குறள் மற்றும் பல)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_156_1767678515699918054.jpg)

SAVES
Computer Science

Learn to form Cursive Small Letters

## Cursive Writing Books

Learn to form Cursive Capital Letters

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_161_1767678515708890391.jpg)

Learn to Write Cursive Words & Short Sentences

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_163_1767678515710964161.jpg)

Learn to Write Cursive Words & Simple Sentences

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_165_1767678515714422356.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_166_1767678515716785952.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_167_1767678515727016670.jpg)

Learn to Write Words and Sentences using Cursive Small & Capital letters

Practice Writing Sentences in Cursive

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_170_1767678515732095285.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_171_1767678515741794509.jpg)

Learn to Write Sentences yourself in Cursive

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_173_1767678515757443466.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_174_1767678515767563803.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_175_1767678515772023885.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_176_1767678515781174727.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1767678515/cropped_image_177_1767678515787078411.jpg)