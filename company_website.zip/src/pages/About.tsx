import Navigation from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Users, Award, Target, History, Globe, CheckCircle } from "lucide-react";

const About = () => {
  const milestones = [
    {
      year: "2000s",
      title: "Foundation",
      description: "Started as pioneers in implementing Computer Literacy Programme at schools"
    },
    {
      year: "2010s",
      title: "Expansion",
      description: "Extended coverage across Tamil Nadu and neighboring states"
    },
    {
      year: "2020s",
      title: "Innovation",
      description: "Introduced AI, robotics, and modern programming concepts"
    },
    {
      year: "Present",
      title: "Leadership",
      description: "Trusted by 1500+ schools across multiple states"
    }
  ];

  const bookSeries = [
    {
      title: "i-Whizz Series",
      description: "Information & Communication Technology covering Windows curriculum with programming languages",
      levels: "Std III to IX"
    },
    {
      title: "Young Wizard Series",
      description: "Multicolour activity-based series covering Windows 7 & Animation curriculum",
      levels: "Level 1 to 5"
    },
    {
      title: "My Computer Series",
      description: "Colourful presentations and workbook activities for primary level",
      levels: "Grade I to V"
    },
    {
      title: "Right Click Series",
      description: "ICT covering Windows with application packages and programming languages",
      levels: "ICT Std III to IX"
    },
    {
      title: "Little Wizard Series",
      description: "Complete instructions for teachers, parents and students for kindergarten",
      levels: "Kids Level 1 & 2"
    },
    {
      title: "My First Stroke Series",
      description: "Cursive Writing and Tamil Writing Books for handwriting improvement",
      levels: "LKG to Std V"
    }
  ];

  const coverage = [
    "Windows 10 platform and MS Office suite",
    "Programming languages: C++, JavaScript, Python, HTML",
    "Database management with MySQL and MS Access",
    "Emerging technologies: AI, Robotics, IoT",
    "Creative tools: Photoshop, SwishMax, Macromedia Flash",
    "Algorithm and coding with Scratch Jr and Scratch 3.0"
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-secondary text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-white/20 text-white border-white/30 mb-6">
              About SAMSEL Publications
            </Badge>
            <h1 className="text-5xl font-bold mb-6">
              Pioneering Computer Education
              <span className="block text-yellow-300">for Over 2 Decades</span>
            </h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              A unit of U.S. UNIQUE SOFTWARE SOLUTIONS, we are the leading company in Chennai providing Total IT Solutions for schools and pioneering Computer Literacy Programmes.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            <Card className="border-primary/20 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Target className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-2xl">Our Mission</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base leading-relaxed">
                  To provide comprehensive, systematic, and innovative computer education solutions that empower students with essential IT skills and prepare them for the digital future. We strive to make quality computer education accessible to schools across India.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-secondary/20 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center mb-4">
                  <Award className="h-6 w-6 text-secondary" />
                </div>
                <CardTitle className="text-2xl">Our Vision</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base leading-relaxed">
                  To be the leading educational publisher in India, recognized for excellence in computer education curriculum and innovative teaching methodologies. We envision a future where every student has access to quality IT education.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Company Story */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Our Story</h2>
              <div className="space-y-6 text-lg text-gray-700">
                <p>
                  SAMSEL Publications began as a visionary initiative to bridge the gap between traditional education and the rapidly evolving world of information technology. As a unit of U.S. UNIQUE SOFTWARE SOLUTIONS, we recognized the critical need for structured computer education in schools.
                </p>
                <p>
                  Our success is truly based on the systematic curriculum framed by us, understanding the IQ level of students at different grades through years of experience with high expertise, commitment, and an innovative team of faculty members and editorial board members.
                </p>
                <p>
                  With state-of-the-art technology ever changing, we regularly upgrade our titles, keeping pace with the latest trends in IT technology and incorporating valuable suggestions from major institutions across states.
                </p>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1758518730083-4c12527b6742?w=600&auto=format&fit=crop&q=80" 
                alt="Educational Team" 
                className="rounded-lg shadow-lg"
              />
              <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-lg shadow-lg">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">20+</div>
                  <div className="text-sm text-gray-600">Years of Excellence</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Journey</h2>
            <p className="text-xl text-muted-foreground">
              Two decades of innovation and growth in computer education
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {milestones.map((milestone, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <History className="h-8 w-8 text-white" />
                </div>
                <div className="text-lg font-semibold text-primary mb-2">{milestone.year}</div>
                <h3 className="text-xl font-bold mb-2">{milestone.title}</h3>
                <p className="text-gray-600">{milestone.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Book Series */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Book Series</h2>
            <p className="text-xl text-muted-foreground">
              Comprehensive educational materials for all levels
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {bookSeries.map((series, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <BookOpen className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{series.title}</CardTitle>
                  <Badge variant="secondary">{series.levels}</Badge>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{series.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Curriculum Coverage */}
      <section className="py-20 bg-primary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-6">Comprehensive Curriculum Coverage</h2>
              <p className="text-xl text-white/90 mb-8">
                Our curriculum covers the latest technologies and programming languages, ensuring students are prepared for the digital future.
              </p>
              
              <div className="grid sm:grid-cols-2 gap-4">
                {coverage.map((item, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-yellow-300 flex-shrink-0" />
                    <span className="text-white/90">{item}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1719159381981-1327b22aff9b?w=600&auto=format&fit=crop&q=80" 
                alt="Computer Lab" 
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Geographic Coverage */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-12">
            <Globe className="h-16 w-16 mx-auto mb-6 text-primary" />
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Pan-India Presence</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              We are accredited by more than 1500 schools across multiple states, with major group institutions following our curriculum.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6">
            {["Tamil Nadu", "Andhra Pradesh", "Kerala", "Karnataka", "Northern India"].map((state, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-lg">
                <Users className="h-8 w-8 mx-auto mb-4 text-primary" />
                <h3 className="font-semibold text-gray-900">{state}</h3>
                <p className="text-sm text-gray-600 mt-2">State/CBSE/ICSE Coverage</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <BookOpen className="h-8 w-8 text-primary" />
                <div>
                  <div className="text-xl font-bold">SAMSEL Publications</div>
                  <div className="text-sm text-gray-400">A unit of U.S. UNIQUE SOFTWARE SOLUTIONS</div>
                </div>
              </div>
              <p className="text-gray-300 mb-4">
                Leading provider of computer education books and IT solutions for schools across India.
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><a href="/" className="text-gray-300 hover:text-white transition-colors">Home</a></li>
                <li><a href="/about" className="text-gray-300 hover:text-white transition-colors">About Us</a></li>
                <li><a href="/contact" className="text-gray-300 hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Account</h3>
              <ul className="space-y-2">
                <li><a href="/login" className="text-gray-300 hover:text-white transition-colors">Login</a></li>
                <li><a href="/signup" className="text-gray-300 hover:text-white transition-colors">Sign Up</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2026 SAMSEL Publications. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default About;