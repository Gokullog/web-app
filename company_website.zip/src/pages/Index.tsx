import Navigation from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { BookOpen, Users, Award, Lightbulb, ArrowRight, CheckCircle, Star, Globe, School } from "lucide-react";

const Index = () => {
  const features = [
    {
      icon: BookOpen,
      title: "Graded Quality Books",
      description: "Comprehensive textbook cum workbook style covering cumulative syllabus for all primary levels."
    },
    {
      icon: Award,
      title: "Expert Curriculum",
      description: "Systematic curriculum framed by experienced faculty with high expertise and commitment."
    },
    {
      icon: Lightbulb,
      title: "Activity Corner",
      description: "Interactive learning with activity-based approach and hands-on exercises."
    },
    {
      icon: Users,
      title: "Supportive Services",
      description: "Monthly schedules, software support, question papers, and teacher's key books."
    }
  ];

  const services = [
    "Work Sheets",
    "Interactive Exercises",
    "Online Exam Software",
    "e-Book Software Voice Enabled",
    "Monthly Tentative Schedule",
    "Terminal Question Papers",
    "Teachers Key Book",
    "Required Software Support"
  ];

  const stats = [
    { number: "1500+", label: "Schools Accredited" },
    { number: "20+", label: "Years Experience" },
    { number: "5", label: "States Coverage" },
    { number: "100%", label: "Quality Assurance" }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary via-primary to-secondary text-white py-20 overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge className="bg-white/20 text-white border-white/30 hover:bg-white/30">
                  Leading Educational Publisher
                </Badge>
                <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
                  Computer Books for
                  <span className="block text-yellow-300">Academic Excellence</span>
                </h1>
                <p className="text-xl text-white/90 leading-relaxed">
                  SAMSEL Publications - A unit of U.S. UNIQUE SOFTWARE SOLUTIONS, providing comprehensive IT education solutions for schools across India for over 2 decades.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-white text-primary hover:bg-white/90 shadow-lg" asChild>
                  <Link to="/about" className="flex items-center space-x-2">
                    <span>Learn More</span>
                    <ArrowRight className="h-5 w-5" />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10" asChild>
                  <Link to="/contact">Get In Touch</Link>
                </Button>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1569653402334-2e98fbaa80ee?w=600&auto=format&fit=crop&q=80" 
                alt="Computer Education Lab" 
                className="rounded-lg shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-lg shadow-lg">
                <div className="flex items-center space-x-2">
                  <Star className="h-5 w-5 text-yellow-500 fill-current" />
                  <span className="font-semibold text-gray-900">Trusted by 1500+ Schools</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-primary mb-2">{stat.number}</div>
                <div className="text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Why Choose SAMSEL Publications?</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              We provide comprehensive educational solutions with systematic curriculum and expert support.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="mx-auto w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <CardTitle className="text-xl">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base">{feature.description}</CardDescription>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Value Added Services</h2>
              <p className="text-lg text-muted-foreground mb-8">
                We provide comprehensive support services to ensure effective curriculum implementation and enhanced learning experience.
              </p>
              
              <div className="grid sm:grid-cols-2 gap-4">
                {services.map((service, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-secondary flex-shrink-0" />
                    <span className="text-gray-700">{service}</span>
                  </div>
                ))}
              </div>
              
              <Button className="mt-8" asChild>
                <Link to="/contact">Request Services</Link>
              </Button>
            </div>
            
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1758270705290-62b6294dd044?w=600&auto=format&fit=crop&q=80" 
                alt="Students Learning" 
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Coverage Section */}
      <section className="py-20 bg-primary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-12">
            <Globe className="h-16 w-16 mx-auto mb-6 text-yellow-300" />
            <h2 className="text-4xl font-bold mb-4">Pan-India Coverage</h2>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              Our books are widely accepted across Tamil Nadu, Andhra Pradesh, Kerala, Karnataka & Northern India for State/CBSE/ICSE board syllabus.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white/10 p-6 rounded-lg">
              <School className="h-8 w-8 mx-auto mb-4 text-yellow-300" />
              <h3 className="text-xl font-semibold mb-2">State Boards</h3>
              <p className="text-white/80">Comprehensive coverage for all state board curricula</p>
            </div>
            <div className="bg-white/10 p-6 rounded-lg">
              <Award className="h-8 w-8 mx-auto mb-4 text-yellow-300" />
              <h3 className="text-xl font-semibold mb-2">CBSE</h3>
              <p className="text-white/80">Aligned with CBSE computer science standards</p>
            </div>
            <div className="bg-white/10 p-6 rounded-lg">
              <Star className="h-8 w-8 mx-auto mb-4 text-yellow-300" />
              <h3 className="text-xl font-semibold mb-2">ICSE</h3>
              <p className="text-white/80">Complete ICSE computer studies curriculum</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Transform Education?</h2>
          <p className="text-xl text-gray-300 mb-8">
            Join 1500+ schools that trust SAMSEL Publications for quality computer education.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary hover:bg-primary/90" asChild>
              <Link to="/contact">Get Started Today</Link>
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10" asChild>
              <Link to="/about">Learn About Us</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <BookOpen className="h-8 w-8 text-primary" />
                <div>
                  <div className="text-xl font-bold">SAMSEL Publications</div>
                  <div className="text-sm text-gray-400">A unit of U.S. UNIQUE SOFTWARE SOLUTIONS</div>
                </div>
              </div>
              <p className="text-gray-300 mb-4">
                Leading provider of computer education books and IT solutions for schools across India.
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><Link to="/" className="text-gray-300 hover:text-white transition-colors">Home</Link></li>
                <li><Link to="/about" className="text-gray-300 hover:text-white transition-colors">About Us</Link></li>
                <li><Link to="/contact" className="text-gray-300 hover:text-white transition-colors">Contact</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Account</h3>
              <ul className="space-y-2">
                <li><Link to="/login" className="text-gray-300 hover:text-white transition-colors">Login</Link></li>
                <li><Link to="/signup" className="text-gray-300 hover:text-white transition-colors">Sign Up</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2026 SAMSEL Publications. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
